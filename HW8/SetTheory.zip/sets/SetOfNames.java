package sets;
import java.util.*;

public class SetOfNames {
	ArrayList<String> nameSet;

	/**
	 * Constructor
	 */
	public SetOfNames() {
		this.nameSet = new ArrayList<String>();
	}
	
	/**
	 * adds a single string to our set of names. returns nothing
	 * @param s
	 */
	public void add(String s) {
		this.nameSet.add(s);
	}
	
	/**
	 * Adds an array of strings to the set
	 * @param string_array
	 */
	public void add(ArrayList<String> string_array) {
		this.nameSet.addAll(string_array);
	}
	
	/**
	 * delete a particular string from the array. only deletes the first instance of that string
	 * @param s
	 */
	public void delete(String s) {
		this.nameSet.remove(this.nameSet.indexOf(s));
	}
	
	/**
	 * checks whether a given string is an element of the set. returns a boolean
	 * @param s
	 */
	public boolean isElementOf(String s) {
		return this.nameSet.contains(s);
	}
	
	
	/**
	 * returns a string representation of our set, in sorted alphabetical order
	 */
	public String toString() {
		if (this.nameSet.size() == 0) {
			return "emptySet";
		}
		else {
			String s = "";
			Collections.sort(this.nameSet);
			for (String name : this.nameSet) {
				s += name + ", ";
			}
			return "{" + s.substring(0, s.length() - 2) + "}";
		}

		
	}

	public static void main(String[] args) {
		SetOfNames vanHalen = new SetOfNames();
		
		//construct list of rocker names
		ArrayList<String> rocker_names = new ArrayList<String>();
		rocker_names.add("Eddie Van Halen");
		rocker_names.add("David Lee Roth");
		rocker_names.add("Alex Van Halen");
		rocker_names.add("Michael Anthony");
		
		//add that arraylist of rockernames to vanHalen
		vanHalen.add(rocker_names);
		System.out.println(vanHalen.toString());
		
		//delete David Lee Roth :(
		vanHalen.delete("David Lee Roth");
		System.out.println(vanHalen.toString());
		
		//add Sammy Hagar!!!
		vanHalen.add("Sammy Hagar");
		System.out.println(vanHalen.toString());
	}

}
