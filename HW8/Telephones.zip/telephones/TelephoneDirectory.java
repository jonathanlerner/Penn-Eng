package telephones;

import java.util.*;

public class TelephoneDirectory {
	
	HashMap<String, String> Directory;

	/**
	 * The constructor
	 */
	public TelephoneDirectory() {
		this.Directory = new HashMap<String, String>();
	}
	

	/**
	 * add a single new person to the directory.
	 * phone number will be a string in the xxx-xxx-xxxx format
	 * @param name
	 * @param phone
	 */
	public void addEntry(String name, String phone) {
		this.Directory.put(name, phone);
	}
	

	/**
	 * get the number given a name
	 * @param name
	 * @return
	 */
	public String getNumber(String name) {
		if(this.Directory.containsKey(name)) {
			return Directory.get(name);
		}
		return "This person is not in the directory.";
	}
	
	/**
	 * given a phone number (as a string) return who it belongs to
	 * @param search_phone_num
	 * @return
	 */
	public String whoCalled(String search_phone_num) {
		Set<String> names = this.Directory.keySet();
		for (String name : names) {
			if (this.Directory.get(name).equals(search_phone_num)) {
				return name;
			}
		}
		return "";
	}
	
	/**
	 * given a source directory, copy all names to this directory.
	 * make sure any existing information is not destroyed.
	 * @param New_Dir
	 */
	public void copyDirectory(TelephoneDirectory Source_Directory) {
		this.Directory.putAll(Source_Directory.Directory);
		
	}
	
	/**
	 * returns a string of the directory entries one by one.
	 * Ensure that the directory is returned in sorted order.
	 */
	public String toString() {
		String s = "";
		Set<String> names = this.Directory.keySet();
		ArrayList<String> namesList = new ArrayList<String>();
		//add every name to this array list.
		for (String name : names) {
			namesList.add(name);
		}
		
		//sort list
		Collections.sort(namesList);
		
		//create the final string
		for (int i = 0; i < namesList.size(); i++) {
			String curr_name = namesList.get(i);
			s += curr_name + " : " + this.Directory.get(curr_name) + "\n";
		}
		return s;
	}

	public static void main(String[] args) {
		TelephoneDirectory td = new TelephoneDirectory();
		td.addEntry("Dawn", "551-421-4032");
		td.addEntry("Arvind", "266-123-1111");
		
		TelephoneDirectory td1 = new TelephoneDirectory();
		td1.addEntry("Tyke","913-232-4851");
		td1.copyDirectory(td);
		System.out.println("Here are all the entries in the directory");
		System.out.println(td1.toString());
		
		//new parts of main function (as requested in the assignment) below:
		System.out.println("Arvind's phone number is " + td1.getNumber("Arvind"));
		System.out.println("We received a call from 913-232-4851. According to the directory, this number belongs to " + td1.whoCalled("913-232-4851") + ".");
		

	}

}
